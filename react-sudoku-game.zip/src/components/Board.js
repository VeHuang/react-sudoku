import React, { Component } from 'react';
import Cell from './Cell';
var sudoku = require('../utils/sudoku');
var _ = require('lodash');

class Board extends Component {
    constructor(props) {
        super(props);
        const puzzle = sudoku.makepuzzle();
        this.state = {
            puzzle: puzzle,
            nextPuzzle: puzzle,
            solvePuzzle: sudoku.solvepuzzle(puzzle),
            clickedCellIndex: null,
            highlightNumber: null,
            invalidIndex: null,
        };
    }

    handleClick(e, index) {
        if (this.state.invalidIndex) {
            return;
        }

        if (this.state.puzzle[index] !== null) {
            this.setState({
                highlightNumber: this.state.puzzle[index] + 1,
                clickedCellIndex: null
            });
        } else {
            this.setState({
                highlightNumber: null,
                clickedCellIndex: index
            });
        }
    }

    validateCell(index, number) {
        if (number === null) {
            return true;
        }
        let row = Math.floor(index / 9),
            col = index % 9,
            squareRow = Math.floor(row / 3),
            squareCol = Math.floor(col / 3);
        let squareUnits = [],
            verticalUnits = [],
            horizontalUnits = [];
        for (let i = 0; i < 9; i++) {
            horizontalUnits.push(this.state.nextPuzzle[row * 9 + i]);
            verticalUnits.push(this.state.nextPuzzle[i * 9 + col]);
        }

        for (let i = squareRow * 3; i < (squareRow + 1) * 3; i++) {
            for (let j = squareCol * 3; j < (squareCol + 1) * 3; j++) {
                squareUnits.push(this.state.nextPuzzle[i * 9 + j]);
            }
        }
        return _.indexOf(_.union(squareUnits, verticalUnits, horizontalUnits), number) < 0;
    }

    handleKeyDown(e, index) {
        //backspance, delete
        if (e.keyCode == 8 || e.keyCode == 46) {
            let nextPuzzle = this.state.nextPuzzle.slice();
            nextPuzzle[index] = null;
            this.setState({
                nextPuzzle: nextPuzzle,
                invalidIndex: null
            });
        }
        // ENTER, ESC
        else if (e.keyCode == 13 || e.keyCode == 27) {
            this.setState({
                clickedCellIndex: null
            });
        }// digits between 1-9
        else if (e.keyCode >= 49 && e.keyCode <= 57) {
            let number = e.keyCode - 48;
            let nextPuzzle = this.state.nextPuzzle.slice();
            nextPuzzle[index] = number - 1;
            this.setState({
                nextPuzzle: nextPuzzle
            });

            if (!this.validateCell(index, nextPuzzle[index])) {
                this.setState({
                    invalidIndex: index
                });
            } else {
                this.setState({
                    invalidIndex: null
                });
            }
        }
    }

    render() {
        const stack = [1, 2, 3, 4, 5, 6, 7, 8, 9];
        return (
            stack.map((item, i) => {
                return (
                    <div key={item} className='row' id={'row' + item} >
                        {
                            stack.map((item, j) => {
                                let index = i * 9 + j;
                                return (
                                    <Cell
                                        key={item}
                                        clickedCellIndex={this.state.clickedCellIndex}
                                        cellIndex={index}
                                        solved={this.state.puzzle[index] !== null}
                                        invalidIndex={this.state.invalidIndex}
                                        highlightNumber={this.state.highlightNumber}
                                        value={this.state.nextPuzzle[index] === null ? '' : this.state.nextPuzzle[index] + 1}
                                        onClick={(e) => { this.handleClick(e, index) }}
                                        onKeyDown={(e) => { this.handleKeyDown(e, index) }}>
                                    </Cell>
                                );
                            })
                        }
                    </div>
                );
            })
        );
    }
}

export default Board;